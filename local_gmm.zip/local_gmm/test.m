a=rand(3,3,3);
b=reshape_NMD(a);