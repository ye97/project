a=rand(4,3);
b=diag(a);